export interface IReference {
  _id: object;
  chapterId: object;
  userId: object;
  interviewId: object;
  userInterviewId: object;
  name: string;
  relationShip: string;
  position: string;
  phoneNumber: string;
}
