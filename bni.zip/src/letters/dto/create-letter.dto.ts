export class CreateLetterDto {}
