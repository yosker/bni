export const jwtConstants = {
  secret: process.env.JWT_SECRET || 'y0sk3r1v01c313*',
};
