export class ServicesResponse {
  statusCode = 200;
  message = 'SUCCESS';
  result = {};
}
