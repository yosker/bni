import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type InterviewsDocument = UsersInterviews & Document;

@Schema()
export class UsersInterviews {
  @Prop({ type: 'object' })
  userId: object;

  @Prop({ type: 'object' })
  userInterviewId: object;

  @Prop({ type: 'object' })
  chapterId: object;

  @Prop({ type: 'object' })
  interviewId: object;

  @Prop({ type: 'string' })
  question1: string;

  @Prop({ type: 'string' })
  question2: string;

  @Prop({ type: 'string' })
  question3: string;

  @Prop({ type: 'array' })
  question4: number[];

  @Prop({ type: 'string' })
  question5: string;

  @Prop({ type: 'string' })
  question6: string;

  @Prop({ type: 'array' })
  question7: number[];

  @Prop({ type: 'string' })
  question8: string;

  @Prop({ type: 'string' })
  question9: string;

  @Prop({ type: 'object' })
  question10: object;

  @Prop({ type: 'string' })
  question11: string;

  @Prop({ type: 'array' })
  question12: number[];

  @Prop({ type: 'string' })
  question13: string;
}

export const UsersInterviewsSchema =
  SchemaFactory.createForClass(UsersInterviews);
