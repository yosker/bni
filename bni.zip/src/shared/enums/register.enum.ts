export enum EstatusRegister {
  Active = 'Active',
  Inactive = 'Inactive',
  Pending = 'Pending',
  Deleted = 'Deleted',
  Accepted = 'Accepted',
  Rejected = 'Rejected',
  Solved = 'Solved',
}
