export enum AttendanceType {
  OnSite = 'presencial',
}
