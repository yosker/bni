export interface Commitments {
    id: number;
    commitmentType: string;
    description: string;
    }