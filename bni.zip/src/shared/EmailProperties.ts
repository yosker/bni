export interface EmailProperties {
  email: string;
  from: string,
  password: string;
  name: string;
  urlPlatform: string;
  template: any;
  subject: string;
  amount: string;
}
